package com.einfochips.constraintcolour

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setOnListiner() // creating the functionalities of the function here
    }

    private fun setOnListiner()
    {
        // collecting all the boxes into the list (id's of textview and buttons)
        val clickableViews : List<View> =
            listOf(box_one_text, box_two_text, box_three_text, box_four_text, box_five_text,
            button1, button2, button3, button4, button5)

        for(item in clickableViews)
        {
            // fetching the id one by one and passing it to the makeColour
            item.setOnClickListener { makeColour(it) } // it is used for the reference
        }
    }

    @SuppressLint("ResourceAsColor")
    private fun makeColour(view: View)
    {
        when(view.id){ // here id will come
            // according to the id it will generates the background color
            R.id.box_one_text -> view.setBackgroundColor(Color.BLUE) // directly getting color from the system
            R.id.box_two_text -> view.setBackgroundColor(Color.GREEN)
            R.id.box_three_text -> view.setBackgroundColor(Color.RED)
            R.id.box_four_text -> view.setBackgroundColor(Color.YELLOW)
            R.id.box_five_text -> view.setBackgroundColor(Color.DKGRAY)

            // for buttons
            R.id.button1 -> box_three_text.setBackgroundColor(Color.RED) // here geting color from color resources
            R.id.button2 -> box_one_text.setBackgroundColor(Color.BLUE)
            R.id.button3 -> box_two_text.setBackgroundColor(Color.GREEN)
            R.id.button4 -> box_four_text.setBackgroundColor(Color.YELLOW)
            R.id.button5 -> box_five_text.setBackgroundColor(Color.DKGRAY)

            else-> view.setBackgroundColor(Color.GRAY)

        }
    }
}